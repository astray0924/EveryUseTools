function submit_and_sort(sort_value) {
	search_form.sort.value = sort_value;
	search_form.submit();
}
;
